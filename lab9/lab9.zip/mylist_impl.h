//
// Created by cyx on 20-5-29.
//

#ifndef INTLIST_IMPL_H
#define INTLIST_IMPL_H

#include <iostream>
#include "mylist.h"

template <class T>
void List<T>::print(){
    Node_t<T>* itr = first;
    while(itr){
        std::cout << itr->val;
        itr = itr->next;
    }
    std::cout << "\n";
}

template <class T>
void List<T>::removeAll(){
    for(Node_t<T> *p=first; p;){
        Node_t<T> *victim = p;
        p=p->next;
        delete victim;
    }
}

template <class T>
static Node_t<T> *copyFromHelp(Node_t<T> *p){
    if(!p) return nullptr;
    Node_t<T> *node = copyFromHelp(p->next);
    Node_t<T> *first = new Node_t<T>;
    first->next = node;
    first->val = p->val;
    return first;
}

template <class T>
void List<T>::copyFrom(const List &l){
    removeAll();
    first = copyFromHelp(l.first);
    if(!first) return;
    Node_t<T> *p;
    for(p = first; !p->next; p=p->next);
    last = p;
}

template <class T>
bool List<T>::isEmpty() const{
    return !first;
}

template <class T>
void List<T>::insertBack(T val){
    Node_t<T> *newP = new Node_t<T>;
    newP->val = val;
    newP->next = nullptr;
    if(!last){
        last = newP;
        first = newP;
    }
    else{
        last->next = newP;
        last = newP;
    }
}

template <class T>
T List<T>::removeFront(){
    if(!first) throw EmptyList();
    Node_t<T> *victim = first;
    T value = victim->val;
    first = first->next;
    delete victim;
    return value;
       
}

template <class T>
const Node_t<T>* List<T>::returnFront() const{
    return first;
}

template <class T>
List<T>::List():first(nullptr), last(nullptr) {}

template <class T>
List<T>::List(const List &l):first(nullptr), last(nullptr){
    copyFrom(l);
}

template <class T>
List<T> &List<T>::operator=(const List<T> &l){
    copyFrom(l);
    return *this;
}

template <class T>
List<T>::~List(){
    removeAll();
}


bool isLarger(const List<int> &a, const List<int> &b){
    const Node_t<int> *pa = a.returnFront();
    const Node_t<int> *pb = b.returnFront();
    bool larger = false;
    while(pa&&pb){
        if(pa->val>pb->val) larger = true;
        else if(pa->val<pb->val) larger = false;
        pa=pa->next;
        pb=pb->next;
    }
    if(!pa&&!pb) return larger;
    else if(!pa) return false;
    else return true;
}

List<int> add(const List<int> &a, const List<int> &b){
    const Node_t<int> *pa = a.returnFront();
    const Node_t<int> *pb = b.returnFront();
    List<int> sum ;
    int carry = 0;
    while(pa&&pb){
        if(carry+pa->val+pb->val>=10){
            sum.insertBack(carry+pa->val+pb->val-10);
            carry=1;
        }
        else{
            sum.insertBack(carry+pa->val+pb->val);
            carry=0;
        }
        pa=pa->next;
        pb=pb->next;
    }
    while(pa){
        if(carry+pa->val>=10){
            sum.insertBack(carry+pa->val-10);
            carry=1;
        }
        else{
            sum.insertBack(carry+pa->val);
            carry=0;
        }
        pa = pa->next;
    }
    while(pb){
         if(carry+pb->val>=10){
            sum.insertBack(carry+pb->val-10);
            carry=1;
        }
        else{
            sum.insertBack(carry+pb->val);
            carry=0;
        }
        pb = pb->next;
    }
    if(carry==1) sum.insertBack(1);
    return sum;
}
#endif //INTLIST_IMPL_H
